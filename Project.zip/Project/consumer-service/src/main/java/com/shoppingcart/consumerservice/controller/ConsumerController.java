package com.shoppingcart.consumerservice.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConsumerController {

}
