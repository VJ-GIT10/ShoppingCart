package com.shoppingcart.consumerservice.configuration;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.context.annotation.Configuration;

import com.shoppingcart.consumerservice.dto.ProductDto;

@Configuration
public class Consumer {

	@RabbitListener(queues = "rabbitMq")
	public void ConsumeTheMessage(ProductDto product) {
		System.out.println("Product Details Fetched");
		System.out.println("Product Details Fetched :" +product.toString());
	}
}
