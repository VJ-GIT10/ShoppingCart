package com.shoppingcart.consumerservice.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ProductDto {
	private int id;
	private String category;
	private String name;
	private double price;
	private boolean inStock;
}
