package com.shoppingcart.productservice.configuration;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;



@Configuration
public class ProducerConfiguration {

	@Bean
	public Queue quee() {
		return new Queue("rabbitMq");
	}

	@Bean
	public TopicExchange exchange() {
		return new TopicExchange("rabbitTopic");
	}
	
	@Bean
	public Binding binding(Queue quee,TopicExchange exchange) {
		return BindingBuilder.bind(quee).to(exchange).with("rabbitRoutingKey");
	}
	
	@Bean
	public MessageConverter converter() {
		return new Jackson2JsonMessageConverter();
	}
	
	@Bean
	public AmqpTemplate template(ConnectionFactory connection) {
		final RabbitTemplate template = new RabbitTemplate(connection);
		template.setMessageConverter(converter());
		return template;
	}
}
