package com.shoppingcart.productservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductserviceProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductserviceProducerApplication.class, args);
	}

}
