package com.shoppingcart.productservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shoppingcart.productservice.entity.Product;
import com.shoppingcart.productservice.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productrepository;

	@Autowired
	private RabbitTemplate template;

	public String add(Product product) {
		productrepository.save(product);
		return "Product Saved Successfully";
	}

	public List<Product> get() {
		List<Product> products = productrepository.findAll();
		template.convertSendAndReceive("rabbitTopic", "rabbitRoutingKey", products);
		return products;
	}

	public Product byId(int id) {
		Optional<Product> product = productrepository.findById(id);
		if (product.isPresent()) {
			template.convertSendAndReceive("rabbitTopic", "rabbitRoutingKey", product);
			return product.get();
		} else {
			return null;
		}
	}

	public String remove(int id) {
		productrepository.deleteById(id);
		return "Deleted Successfully";
	}
}
