package com.shoppingcart.productservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.shoppingcart.productservice.entity.Product;
import com.shoppingcart.productservice.service.ProductService;

@RestController
@RequestMapping("/Products")
public class ProductController {

	@Autowired
	private ProductService productservice;

	@PostMapping("/add")
	public String addProducts(@RequestBody Product product) {
		String status = productservice.add(product);
		return status;
	}

	@GetMapping("/getAll")
	public List<Product> get() {
		return productservice.get();
	}

	@GetMapping("/ById/{id}")
	public ResponseEntity<?> getById(@RequestParam int id) {
		Product lstProduct = productservice.byId(id);
		if (lstProduct == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<Product>(lstProduct, HttpStatus.OK);
		}
	}

	@DeleteMapping("/delete/{id}")
	public String delete(@RequestParam int id) {
		return productservice.remove(id);
	}
}
